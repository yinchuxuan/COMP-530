
#ifndef BPLUS_SELECTION_C                                        
#define BPLUS_SELECTION_C

#include "BPlusSelection.h"

BPlusSelection :: BPlusSelection (MyDB_BPlusTreeReaderWriterPtr, MyDB_TableReaderWriterPtr,
                MyDB_AttValPtr, MyDB_AttValPtr,
                string, vector <string>) {}

void BPlusSelection :: run () {}

#endif
