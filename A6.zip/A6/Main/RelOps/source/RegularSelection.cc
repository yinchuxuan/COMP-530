
#ifndef REG_SELECTION_C                                        
#define REG_SELECTION_C

#include "RegularSelection.h"

RegularSelection :: RegularSelection (MyDB_TableReaderWriterPtr, MyDB_TableReaderWriterPtr,
                string, vector <string>) {}

void RegularSelection :: run () {}

#endif
